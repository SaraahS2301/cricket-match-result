const express = require('express');
const fs = require('fs');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));

app.get('/predict', (req, res) => {
  const { teamA, teamB } = req.query;
  const teamA_wins = data[teamA][teamB];
  const teamB_wins = data[teamB][teamA];

  const winner =
    teamA_wins > teamB_wins ? teamA :
    teamB_wins > teamA_wins ? teamB :
    "Draw";

  res.json({ winner });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));